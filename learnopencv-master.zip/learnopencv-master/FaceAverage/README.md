Please see the following [blog post](https://www.learnopencv.com/average-face-opencv-c-python-tutorial/) for more details about this code

[Average Face : OpenCV ( C++ / Python ) Tutorial](https://www.learnopencv.com/average-face-opencv-c-python-tutorial/)
