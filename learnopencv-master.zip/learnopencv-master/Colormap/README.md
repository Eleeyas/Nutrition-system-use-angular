Please see the following [blog post](https://www.learnopencv.com/applycolormap-for-pseudocoloring-in-opencv-c-python/) for more details about this code

[applyColorMap for pseudocoloring in OpenCV ( C++ / Python )](https://www.learnopencv.com/applycolormap-for-pseudocoloring-in-opencv-c-python/)
