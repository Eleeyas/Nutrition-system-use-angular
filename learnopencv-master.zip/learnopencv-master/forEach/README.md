Please see the following [blog post](https://www.learnopencv.com/parallel-pixel-access-in-opencv-using-foreach/) for more details about this code

[Parallel Pixel Access in OpenCV using forEach](https://www.learnopencv.com/parallel-pixel-access-in-opencv-using-foreach/)
