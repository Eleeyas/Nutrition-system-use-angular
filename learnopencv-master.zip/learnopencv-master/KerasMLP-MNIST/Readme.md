Please see the following [blog post](https://www.learnopencv.com/image-classification-using-feedforward-neural-network-in-keras/) for more details about this code

[Image Classification using Feedforward Neural Network in Keras](https://www.learnopencv.com/image-classification-using-feedforward-neural-network-in-keras/)

