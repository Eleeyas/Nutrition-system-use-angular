Please see the following [blog post](https://www.learnopencv.com/keras-tutorial-using-pre-trained-imagenet-models/) for more details about this code

[Keras Tutorial : Using pre-trained Imagenet models](https://www.learnopencv.com/keras-tutorial-using-pre-trained-imagenet-models/)
