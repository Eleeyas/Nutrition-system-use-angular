Please see the following [blog post](https://www.learnopencv.com/exposure-fusion-using-opencv-cpp-python/) for more details about this code

[Exposure Fusion using OpenCV (C++/Python)](https://www.learnopencv.com/exposure-fusion-using-opencv-cpp-python/)
