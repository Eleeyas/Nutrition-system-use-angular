Please see the following [blog post](https://www.learnopencv.com/high-dynamic-range-hdr-imaging-using-opencv-cpp-python) for more details about this code

[High Dynamic Range (HDR) Imaging using OpenCV (C++/Python)](https://www.learnopencv.com/high-dynamic-range-hdr-imaging-using-opencv-cpp-python)
