Please see the following [blog post](https://www.learnopencv.com/read-an-image-in-opencv-python-cpp/) for more details about this code

[Read an Image in OpenCV ( Python, C++ )](https://www.learnopencv.com/read-an-image-in-opencv-python-cpp/)
