Please see the following [blog post](https://www.learnopencv.com/handwritten-digits-classification-an-opencv-c-python-tutorial/) for more details about this code

[Handwritten Digits Classification : An OpenCV ( C++ / Python ) Tutorial](https://www.learnopencv.com/handwritten-digits-classification-an-opencv-c-python-tutorial/)
