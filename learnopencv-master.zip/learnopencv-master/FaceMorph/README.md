Please see the following [blog post](https://www.learnopencv.com/face-morph-using-opencv-cpp-python/) for more details about this code

[Face Morph Using OpenCV — C++ / Python](https://www.learnopencv.com/face-morph-using-opencv-cpp-python/)
