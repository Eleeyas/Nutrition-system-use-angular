Please see the following [blog post](https://www.learnopencv.com/warp-one-triangle-to-another-using-opencv-c-python/)  for more details about this code

[Warp one triangle to another using OpenCV ( C++ / Python )](https://www.learnopencv.com/warp-one-triangle-to-another-using-opencv-c-python/) 
