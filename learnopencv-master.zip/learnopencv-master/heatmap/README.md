# Heatmaps for logo detection 

Download data by clicking on the link below

[Heatmap Data](http://media.orpix-inc.com/heatmap-data.zip)

Once the data is generated run the script to produce the heatmap 

```python generate_heatmap.py```
