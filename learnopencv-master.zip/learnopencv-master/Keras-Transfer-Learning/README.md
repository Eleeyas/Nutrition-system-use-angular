Please see the following [blog post](https://www.learnopencv.com/keras-tutorial-transfer-learning-using-pre-trained-models/) for more details about this code

[Keras Tutorial : Transfer Learning using pre-trained models](https://www.learnopencv.com/keras-tutorial-transfer-learning-using-pre-trained-models/)
