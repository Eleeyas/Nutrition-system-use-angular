Please see the following [blog post](https://www.learnopencv.com/configuring-qt-for-opencv-on-osx/) for more details about this code

[Configuring Qt for OpenCV on OSX](https://www.learnopencv.com/configuring-qt-for-opencv-on-osx/)
