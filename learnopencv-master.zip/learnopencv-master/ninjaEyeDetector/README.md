Please see the following [blog post](https://www.learnopencv.com/minified-opencv-haar-and-lbp-cascades/) for more details about this code

[Minified OpenCV Haar and LBP Cascades](https://www.learnopencv.com/minified-opencv-haar-and-lbp-cascades/)
