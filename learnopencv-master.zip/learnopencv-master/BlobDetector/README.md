Please see the following [blog post](https://www.learnopencv.com/blob-detection-using-opencv-python-c/) for more details about this code

[Blob Detection Using OpenCV ( Python, C++ )](https://www.learnopencv.com/blob-detection-using-opencv-python-c/)
