Please see the following [blog post](https://www.learnopencv.com/image-alignment-ecc-in-opencv-c-python/) for more details about this code

[Image Alignment (ECC) in OpenCV ( C++ / Python )](https://www.learnopencv.com/image-alignment-ecc-in-opencv-c-python/)
